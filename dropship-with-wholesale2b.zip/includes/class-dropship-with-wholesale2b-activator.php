<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.wholesale2b.com
 * @since      1.0.0
 *
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 * @author     Aniruddha Pathak, Wholesale2B <support@wholesale2b.com>
 */
class Dropship_With_Wholesale2b_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
