<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.wholesale2b.com
 * @since      1.0.0
 *
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 * @author     Aniruddha Pathak, Wholesale2B <support@wholesale2b.com>
 */
class Dropship_With_Wholesale2b_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'dropship-with-wholesale2b',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
