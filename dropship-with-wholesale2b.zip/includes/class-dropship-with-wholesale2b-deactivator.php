<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.wholesale2b.com
 * @since      1.0.0
 *
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/includes
 * @author     Aniruddha Pathak, Wholesale2B <support@wholesale2b.com>
 */
class Dropship_With_Wholesale2b_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
