<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.wholesale2b.com
 * @since      1.0.0
 *
 * @package    Dropship_With_Wholesale2b
 * @subpackage Dropship_With_Wholesale2b/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
