=== Dropship with Wholesale2B ===
Contributors: aniruddhapathak, onlinestorebiznet
Tags: dropship, woocommerce
Requires at least: 4.4
Tested up to: 5.5.1
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Connect your WooCommerce store to your Wholesale2B dashboard. Get 7-day free trial of the WooCommerce plan for Wholesale2B.

== Description ==
Meet the All-in-One dropshipping solution for your WooCommerce store. Add and sell top-notch products by connecting Wholesale2B to your store.

Dropship with Wholesale2B plugin walks you through the process of signing up with us and provides you with a 7-day trial to access Wholesale2B\'s WooCommerce integration plan for free. You can then use our automated tools to browse through over 1 million products and look for various niches, suppliers, brands, and categories.

Sign Up for our WooCommerce Plan & connect your Wholesale2B account with your WooCommerce website. Once that is done, it\'d help us import products of your choice into your store and automatically sync the inventory, orders, and stock statuses too. 

The process is seamless and takes only one click and one minute of your time.

== Installation ==
1. Install the Dropship with Wholesale2B plugin either via the WordPress plugin directory, or by uploading the files to your server at wp-content/plugins.
2. After activating, go to Dropship with Wholesale2B in your WordPress dashboard and follow the steps mentioned to activate your free trial.

== Frequently Asked Questions ==
= Do you also import the product images to my WooCommerce store? =

Yes, we do. The product images will be loaded to your WooCommerce store when your list is imported to your store.

= Can I make changes to the item names? =

Yes, you can. You can edit the item names and descriptions directly from your list. This is a great way of making the items unique on your site which will help get better SEO.

Please note that all changes need to be done directly on your list because your list is considered as your main source. If you change the prices, or item names or item descriptions directly from your store, then those changes will be overwritten by your list the next time it is synced.

= Do I need to manually import my orders? =

No, you don't have to manually import your orders.

= Which version of WooCommerce should I be using? =

WooCommerce 2.6+

== Screenshots ==
1. Connect with Wholesale2B - A Walkthrough

== Changelog ==
= 1.0.0 =
* Initial release.