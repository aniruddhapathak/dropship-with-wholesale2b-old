<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.wholesale2b.com
 * @since             1.0.0
 * @package           Dropship_With_Wholesale2b
 *
 * @wordpress-plugin
 * Plugin Name:       Dropship with Wholesale2B
 * Plugin URI:        https://www.wholesale2b.com/
 * Description:       Connect your WooCommerce store to your Wholesale2B dashboard. Get 7-day free trial of the WooCommerce plan for Wholesale2B.
 * Version:           1.0.0
 * Author:            Aniruddha Pathak, Wholesale2B
 * Author URI:        https://www.wholesale2b.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       dropship-with-wholesale2b
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'DROPSHIP_WITH_WHOLESALE2B_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-dropship-with-wholesale2b-activator.php
 */
function activate_dropship_with_wholesale2b() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-dropship-with-wholesale2b-activator.php';
	Dropship_With_Wholesale2b_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-dropship-with-wholesale2b-deactivator.php
 */
function deactivate_dropship_with_wholesale2b() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-dropship-with-wholesale2b-deactivator.php';
	Dropship_With_Wholesale2b_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_dropship_with_wholesale2b' );
register_deactivation_hook( __FILE__, 'deactivate_dropship_with_wholesale2b' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-dropship-with-wholesale2b.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_dropship_with_wholesale2b() {

	$plugin = new Dropship_With_Wholesale2b();
	$plugin->run();

}
run_dropship_with_wholesale2b();

function w2b_admin_menu() {
		add_menu_page(
			__( 'Dropship with Wholesale2b', 'my-textdomain' ),
			__( 'Dropship with Wholesale2b', 'my-textdomain' ),
			'manage_options',
			'dropship-with-wholesale2b',
			'w2b_admin_page_contents',
			'dashicons-store',
			3
		);
	}

	add_action( 'admin_menu', 'w2b_admin_menu' );


	function w2b_admin_page_contents() {
		?>
			<h1>
				<?php esc_html_e( 'Welcome to the Best Dropshipping Experience', 'my-plugin-textdomain' ); ?>
			</h1>
			<section>
			<div>
			<h2>How to get started?</h2>
			<h3>Step 1.</h3>
			<p>Create an Account on Wholesale2B.com to</p>
			<ul>
			<li>Browse through 1 Million Dropship Products</li>
 <li>Search & find dropship products with great profits</li>
 <li>Sync to eBay, Amazon, Shopify, WooCommerce, BigCommerce, and more</li>
 <li>Create a new professional store loaded with products</li>
 <li>Import orders automatically & sync inventory and tracking</li>
 <li>Download products & images in CSV files</li>
 </ul>
			<a href="https://www.wholesale2b.com/members.php/signup?utm_source=w2bplugin" target="_blank" class="w2b-button">Click here to get your 7-day free trial</a>
			</div>
			</section>
			<section>
			<div>
			<h3>Step 2.</h3>
			<p>Connect your WooCommerce store to your Wholesale2B dashboard. Once that is done, it'd help us import products of your choice into your store and automatially sync the inventory, orders, and stock statuses too.</p>
			<a href="https://www.wholesale2b.com/knowledge-base/how-to-install-wholesale2b-woocommerce-app.html?utm_source=w2bplugin" target="_blank" class="w2b-button">Click here for the How-to Guide</a>
			</div>
			</section>
			<section>
			<div>
			<h3>Step 3.</h3>
			<p>Start building your list of products that you wish to sell on your WooCommerce store. Use our automated tools to browse through over 1 million products and look for various niches, suppliers, brands, and categories. Filter the list using our functionalities of showing only the products that are best-selling & require low-shipping. Set the profit margins using the global markup feature or on individual products.

Once your list is ready, switch it ON and our algorithm will instantly process it to import products in your store. Get ready for a rocking dropshipping business!</p>
<a href="https://www.wholesale2b.com/knowledge-base/how-to-add-products-to-woocommerce-list.html?utm_source=w2bplugin" target="_blank" class="w2b-button">Click here for the How-to Guide</a>
</div>
			</section>
			<section><div>
			<h3 style="text-align: center; font-size: 30px; line-height: 1.4em;">Step 4: Start selling & Earn Profits!</h3>
			</div>
			<div>
			<h3>Need assistance or support?</h3>
			<p>Are you stuck at something? Do you have any questions? Do you want to report an issue with your store & Wholesale2B? Do you need any customization support? Do not hesitate to contact us.
			
			Before you create a support ticket, please checkout our <a href="https://www.wholesale2b.com/knowledge-base/index.html?utm_source=w2bplugin" target="_blank"/>Dropshipping Learning Center</a>. You might find answers to your questions quickly.</p>
			<a href="https://www.wholesale2b.com/contact.html?utm_source=w2bplugin" target="_blank" class="w2b-button">Click here to Get in Touch</a>
			<h2>What is Wholesale2B?</h2>
			<p>
			Wholesale2b is a software development company with a focus on providing the best dropshipping tools to help online entrepreneurs like you get started with a Dropshipping business quickly and efficiently. Our goal is to increase your online Dropship business revenue with almost no effort and no technical knowledge.
			</p>
			</section>
		<?php
	}

function load_w2b_style($hook) {
        // $hook is string value given add_menu_page function.
        if($hook != 'toplevel_page_dropship-with-wholesale2b') {
                return;
        }
        wp_enqueue_style( 'custom_wp_admin_css', plugins_url('css/w2b.css', __FILE__) );
}
add_action( 'admin_enqueue_scripts', 'load_w2b_style' );
